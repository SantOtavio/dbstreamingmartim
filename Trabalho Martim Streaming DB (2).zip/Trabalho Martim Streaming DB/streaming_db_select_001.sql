-- 1) Séries europeias com >3 temporadas e premiação de atores em ≥2 temporadas
SELECT title
FROM   v_series_eur_actor_awards;

-- 2) Filmes premiados nas categorias diretor E ator
SELECT title
FROM   v_movies_dir_and_actor_award;

-- 3) Séries não europeias com mais atrizes que atores e episódios dirigidos por >1 diretor
SELECT title
FROM   v_series_non_eu_female_major;

-- 4) Premiações de filmes antes de 2003, gênero aventura, classificação >12
SELECT a.*
FROM   award a
JOIN   movie m ON m.movie_id = a.movie_id
JOIN   genre g ON g.genre_id = m.genre_id AND g.name = 'Adventure'
JOIN   age_rating r ON r.rating_id = m.rating_id AND r.min_age > 12
WHERE  m.release_year < 2003;

-- 5) Personagens de ator que fez filmes de romance e nunca foi premiado
SELECT DISTINCT c.name AS character_name
FROM   character c
JOIN   actor_movie am ON am.character_id = c.character_id
JOIN   movie m       ON m.movie_id = am.movie_id
JOIN   genre g       ON g.genre_id = m.genre_id AND g.name = 'Romance'
JOIN   actor a       ON a.actor_id = am.actor_id
WHERE  NOT EXISTS (SELECT 1 FROM award WHERE actor_id = a.actor_id);

-- 6) Episódios (ordem alfabética) de séries com >3 temporadas, dirigidos por mulheres e classificação livre
SELECT title
FROM   v_episodes_female_free_gt3season
ORDER  BY title;

-- 7) Filmes pós‑2003 com atores que participaram de séries premiadas
SELECT title
FROM   v_movies_post2003_cast_awarded_series;

-- 8) Atores com séries somente antes de 2003 e filmes somente depois de 2003 (ordem decrescente de filme)
SELECT a.name,
       m.release_year AS movie_year
FROM   v_actor_oldseries_newmovies a
JOIN   actor_movie am ON am.actor_id = a.actor_id
JOIN   movie m        ON m.movie_id  = am.movie_id AND m.release_year > 2003
ORDER  BY m.release_year DESC;

-- 9) Episódios de séries com ≥4 episódios/temporada >45min e <3 atores nesses episódios
SELECT e.title
FROM   episode e
JOIN   season se ON se.season_id = e.season_id
JOIN   series s  ON s.series_id  = se.series_id
WHERE  e.duration_min > 45
GROUP  BY e.episode_id, e.title, se.season_id
HAVING COUNT(*) >= 1
   AND (SELECT COUNT(*) FROM episode e2 WHERE e2.season_id = se.season_id AND e2.duration_min > 45) >= 4
   AND (SELECT COUNT(DISTINCT actor_id) FROM actor_episode ae WHERE ae.episode_id = e.episode_id) < 3;

-- 10) Filmes 4K dirigidos por um de seus atores
SELECT m.title
FROM   movie m
JOIN   director_movie dm ON dm.movie_id = m.movie_id
JOIN   actor_movie   am ON am.movie_id = m.movie_id AND am.actor_id = dm.director_id
WHERE  m.resolution = '4K';

-- 11) Filmes >3h, ator interpretou a si mesmo, antes de 2010 e premiados
SELECT DISTINCT m.title
FROM   movie m
JOIN   actor_movie am ON am.movie_id = m.movie_id
JOIN   actor a       ON a.actor_id = am.actor_id AND a.name = (SELECT name FROM character WHERE character_id = am.character_id)
WHERE  m.duration_min > 180
  AND  m.release_year < 2010
  AND  EXISTS (SELECT 1 FROM award WHERE movie_id = m.movie_id OR actor_id = a.actor_id OR director_id IN (SELECT director_id FROM director_movie WHERE movie_id = m.movie_id));

-- 12) Episódios, atores e avaliação dos episódios (critérios específicos)
SELECT e.title AS episode_title,
       a.name  AS actor_name,
       ev.rating
FROM   episode e
JOIN   evaluation ev     ON ev.episode_id = e.episode_id
JOIN   actor_episode ae  ON ae.episode_id = e.episode_id
JOIN   actor a           ON a.actor_id    = ae.actor_id
JOIN   season se         ON se.season_id  = e.season_id
JOIN   series s          ON s.series_id   = se.series_id
JOIN   genre g           ON g.genre_id    = s.genre_id AND g.name IN ('Comedy','Action')
WHERE  (SELECT AVG(ev2.rating) FROM evaluation ev2 JOIN episode e2 ON e2.episode_id = ev2.episode_id WHERE e2.season_id = se.season_id) > 7.5
  AND  (SELECT AVG(duration_min) FROM episode e3 WHERE e3.season_id = se.season_id) BETWEEN 45 AND 50
  AND  (SELECT COUNT(DISTINCT director_id) FROM director_episode de WHERE de.episode_id IN (SELECT episode_id FROM episode WHERE season_id = se.season_id)) > 1;

-- 13) Avaliação média de séries e filmes por diretor
SELECT name, work_type, avg_rating
FROM   v_director_avg_rating;

-- 14) Filmes e séries de comédia com ≥2 atores avaliando >8.5
SELECT title, type
FROM   v_comedy_titles_multi_actor_high_rating;